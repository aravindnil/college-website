<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<!-- For IE -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">

		<!-- For Resposive Device -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<title>UNIVERSITY INSTITUTE OF TECHNOLOGY THIRUVANANTHAPURAM</title>

		<!-- Favicon -->
		<link rel="icon" type="image/png" sizes="56x56" href="logo.png">


		<!-- Main style sheet -->
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<!-- responsive style sheet -->
		<link rel="stylesheet" type="text/css" href="css/responsive.css">


		<!-- Fix Internet Explorer ______________________________________-->

		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
			<script src="vendor/html5shiv.js"></script>
			<script src="vendor/respond.js"></script>
		<![endif]-->
			
	</head>
<style>
.logo{
		width:60px;
		height:30px;
	}

@media (max-width: 650px){
	.logo{
		width:60px;
		height:50px;
	}

};
@media (max-width: 650px){
	.placement{
	position: absolute;
	left:auto;
	transform: scale(0.8);
}
}
</style>
       

	<body >
		<div class="main-page-wrapper">



			<!-- 
			=============================================
				Theme Header
			============================================== 
			-->
			<header class="theme-main-header">
				<div class="container">
					<a href="index.html" class="logo float-left tran4s"><img src="logo.gif"   ></a>
					
					<!-- ========================= Theme Feature Page Menu ======================= -->
					<nav class="navbar float-right theme-main-menu">
					   <!-- Brand and toggle get grouped for better mobile display -->
					   <div class="navbar-header">
					     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1" aria-expanded="false">
					       <span class="sr-only">Toggle navigation</span>
					       Menu
					       <i class="fa fa-bars" aria-hidden="true"></i>
					     </button>
					   </div>
					   <!-- Collect the nav links, forms, and other content for toggling -->
					   <div class="collapse navbar-collapse" id="navbar-collapse-1">
					     <ul class="nav navbar-nav">
					       	<li class="active"><a href="index.html">HOME</a></li>
							   <li><a href="notice.html">ANNOUNCEMENTS</a></li>
																					
							
							<li class="dropdown-holder"><a href="#">STUDENTS CORNER</a>
								<ul class="sub-menu">
									<li><a href="campus.html" class="tran3s">CAMPUS</a></li>
									
									<li><a href="clubs.html" class="tran3s">CLUBS</a></li>
									<li><a href="placements.html" class="tran3s">PLACEMENTS</a></li>
									<li><a href="Arhives.html" class="tran3s">ACHIEVEMENTS</a></li>
								</ul>
							
							
							
							</li>
							<li class="dropdown-holder"><a href="#">COMMUNITIES</a>
								<ul class="sub-menu">
									<li><a href="alumni.html" class="active">ALUMNI</a></li>
									
									<li><a href="pta.html" class="tran3s">PTA</a></li>
									<li><a href="faculties.html" class="tran3s">PEOPLE</a></li>
									<li><a href="former.html" class="tran3s">FORMER PRINICPALS</a></li>
									
								</ul>
							
							
							
							</li>
							
							<li><a href="gallery.html" >GALLERY</a></li>
								<li class="dropdown-holder"><a href="academics.html">ACADEMICS</a>
								<ul class="sub-menu">
										<li><a href="cs.html" class="tran3s">COMPUTER SCIENCE </a></li>
										<li><a href="el.html" class="tran3s">ELECTRONICS </a></li>
										
									</ul>
								</li>
								<li><a href="downloads.html">DOWNLOADS</a></li>
								<li><a href="about.html">ABOUT</a></li>
							<li><a href="contact.html">CONTACT</a></li>
					     </ul>
					   </div><!-- /.navbar-collapse -->
					</nav> <!-- /.theme-feature-menu -->
				</div>
			</header> <!-- /.theme-main-header -->


			<!--
			=====================================================
				Theme Inner page Banner
			=====================================================
			-->
			<section class="inner-page-banner">
				<div class="opacity">
					<div class="container">
						<h2><p>UNIVERSITY INSTITUTE OF TECHNOLOGY</p> <br>THIRUVANANTHAPURAM
							
						</h2>
						<ul>
							<a href="about.html"><li><b>ABOUT US</b></li></a>
							
							
						</ul>
					</div> <!-- /.container -->
				</div> <!-- /.opacity -->
			</section> <!-- /.inner-page-banner -->
			














<div id = "Table" >
			
			<!--
			=====================================================
				Blog Page Details
			=====================================================
			-->
			<article class="blog-details-page">
				<div class="container">
					<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 p-fix">
						<div class="blog-details-post-wrapper">
							<img src="c4.jpg" alt="Image" style="width:150%;height:130%;">
							<div class="post-heading">
								<h4>Introduction</h4>
								<!--<span>Posted by <a href="#" class="tran3s p-color">admin</a>  at 04 Feb, 2017</span>-->
							</div> <!-- /.post-heading -->
							<ul>
								<li style=" list-style-type: circle;">.............................</li>
							<li style=" list-style-type: circle;">. 			</li>
						<li style=" list-style-type: circle;">.................... </li>
					<li style=" list-style-type: circle;">............. </li>
				</ul>
			
							<h6>From Principal Desk</h6>
							<p>It is my previlage to introduce you the Universit Institute of Technology,UIT,Thiruvananthapuram,an institution of higher learning,directly run by the University of Keralasince 1995,located near Travencore Palace,kawdiar at the heart of the city.
								we are committed to achieve academic excellence by transferrig and developing young students.The college eccourages and coaches students to become innovative and critical thinkers who produce quality outcom.We groom students to developthe skill,capacity and creativity to leade productive livesand positivelycontribute to communities.
							</p>
							<div class="row">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<br><p><i class="fa fa-quote-left" aria-hidden="true"></i>At this fast evolving institute, our focus is on providing an ambience conducive to developing a career rather than to just getting a job. I am delighted to inform you that, the college has earned its place amongst the upcoming institutes of excellence of kerala, with a potential to develop into a world-class centre of higher technical education over the coming years. I wish all my students, a great success in all their endeavours.<i class="fa fa-quote-right" aria-hidden="true"></i></p>
								</div> <!-- /.col -->
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<img style="height:231px;width:360px;" src="jjjjjjj" alt="Image">
								</div> <!-- /.col- -->
							</div> <!-- /.row -->

							<p>UNIVERSITY INSTITUTE OF TECHNOLOGY was established by the Kerala University in the year 1995 with the aim of imparting quality technical education for the students of Thiruvananthapuram and nearby areas. Since its inception, the faculty and staff have been tirelessly working towards the growth of the institution. </p>
							<div class="clear-fix list-img-wrapper">
								<img src="home1.jpg" alt="Image" class="float-left">
								<ul class="float-left">
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> Quality Education.</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> Modern labs facilities.</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> Highly Qualified Teachers.</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> Supportive seniors.</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> Different fest and Socities.</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> Positive growth rate.</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> University Institution.</a></li>
								</ul>
							</div> <!-- /.list-img-wrapper -->

<!--
							<div class="clear-fix post-share-area">
								<ul class="share float-left">
									<li><a href="#" class="tran3s active">Business,</a></li>
									<li><a href="#" class="tran3s">Advertising ,</a></li>
									<li><a href="#" class="tran3s">Marketing,</a></li>
									<li><a href="#" class="tran3s">Optimization</a></li>
								</ul>
								<ul class="share-icon float-right">
									<li>Share:</li>
									<li><a href="#" class="tran3s round-border"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#" class="tran3s round-border"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#" class="tran3s round-border"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
									<li><a href="#" class="tran3s round-border"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
								</ul>
							</div> <!-- /post-share-area -->
<hr>




<!--     skill section



-->
	



















										<div id="skill-section">
												<div class="container">
													<div class="clear-fix">
														<div class="col-lg-0 col-md-0 col-sm-0 col-xs-1">
															<h1  class="placement" style="color:white;transform: scale(0.8);position:relative;margin-left:1em">PLACEMENTS</h1>
												<!--		<div class="img">  <img src="images/home/2.jpg" alt="Image"> </div>-->
														</div> <!-- /.col- -->
								
														<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
															<div class="skills-progress skills">
																<div class="habilidades_contenedor">
																	<div class="codeconSkills">
																		<div class="codeconSkillbar">
																			<div class="skill-text">
																				<span class="codeconSkillArea">2017</span>
																			</div>
																			<div class="skillBar" data-percent="50%">
																				<span class="PercentText">50%</span>
																			</div>
																		</div>
																		<div class="codeconSkillbar">
																			<div class="skill-text">
																				<span class="codeconSkillArea ">2018</span>
																				
																			</div>
																			<div class="skillBar" data-percent="80%">
																				<span class="PercentText">80%</span>
																			</div>
																		</div>
																		<div class="codeconSkillbar">
																			<div class="skill-text">
																				<span class="codeconSkillArea">CS 2018</span>
																				
																			</div>
																			<div class="skillBar" data-percent="82%">
																				<span class="PercentText">82%</span>
																			</div>
																		</div>
																		<div class="codeconSkillbar">
																			<div class="skill-text">
																				<span class="codeconSkillArea">EC 2018</span>
																				
																			</div>
																			<div class="skillBar" data-percent="76%">
																				<span class="PercentText">76%</span>
																			</div>
																		</div>
																		<div >
																			<div >
																			
																				
																			</div>
																			<div >
																				
																			</div>
																		</div>
																	</div> <!-- /.codeconSkills -->
																</div> <!-- /.habilidades_contenedor -->
															</div> <!-- /.skills-progress -->
														</div>
													</div> <!-- /.clear-fix -->
												</div> <!-- /.container -->
										</div>	 <!-- /#skill-section -->
								
								
				
				





										<div class="comment-area">											
												<div class="comment-wrapper">
								</div> <!-- /.comment-wrapper -->
							</div> <!-- /.comment-area -->
							<div class="post-comment">								
						<div class="row">										
									</div> <!-- /.row -->								
							</div> <!-- /.post-comment -->
						</div> <!-- /.blog-details-post-wrapper -->
					</div> <!-- /.col- -->

					






<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#TableInput").on('click',function() {
	  
		 var value = $(this).val().toLowerCase();
    $("#GbpecTable div").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });	
	
	
   
  });
});
</script>
<!--
 <div class="theme-title">
<h2>Table Search</h2>
<h2><input id = "TableInput" type = "text" placeholder = "Search in table.."><h2>
</div>
-->






























					<!-- ========================== Aside Bar ======================== -->
					
					<br>
					<br>
					<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12 p-fix">
						<aside>


	
					<form class="sidebar-search-box">
				
								<input  id = "TableInput" type="text" placeholder="Search..." name="q">
					</form>			




							
							<div class="sidebar-news-list">
									
								<h6>Latest News</h6>
								<ul>
									<li><a href="#" class="tran3s active"><i class="fa fa-hand-o-right" aria-hidden="true"></i> ...................</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> .....................</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i>..................</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> ....................</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> .....................</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> ...................</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> .................</a></li>
									
								</ul>
							</div> <!-- /.sidebar-news-list -->
<br>
							<div class="sidebar-calendar">
								<h6>Calendar</h6>
								<div class="monthly" id="blog-calendar"></div>








    


















							</div> <!-- /.sidebar-calendar -->

							<div class="sidebar-archives">
								<h6>Archives</h6>
								<ul>
									<li><a href="#" class="tran3s active"><i class="fa fa-hand-o-right" aria-hidden="true"></i> ...........</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> ...............</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> ................</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> ..............</a></li>
									<li><a href="#" class="tran3s"><i class="fa fa-hand-o-right" aria-hidden="true"></i> ..................</a></li>
								</ul>
							</div> <!-- /.sidebar-archives -->

							<div >
								
								<div >
									<div c>
										
									</div> 
								</div> 

								<div >
									
									<div >
										
										
									</div> 
								</div>



								<div >
									<div >
									
									</div>
								</div> 
							


							<div >
								
								<div >
									
								</div> 
							</div> 
                            </div>







							













							<div class="sidebar-tags">
								<h6>Different scholarships available</h6>
								<ul>
									<li><a href="#" class="tran3s">......</a></li>
									<li><a href="#" class="tran3s">..........</a></li>
									<li><a href="#" class="tran3s">...........</a></li>
									<li><a href="#" class="tran3s">.........</a></li>
									<li><a href="#" class="tran3s">.........</a></li>
									<li><a href="#" class="tran3s">.......</a></li>
									
								</ul>
							</div> <!-- /.sidebar-tags -->
						</aside>
					</div> <!-- /.col- -->
				</div> <!-- /.container -->
			</article>
	        



			<!--
			=====================================================
				Footer
			=====================================================
			-->



</div>
<footer class="bg1">
			<div class="container p-t-40 p-b-70">
				<div class="row">
					<div class="col-sm-6 col-md-4 p-t-50">
						<!-- - -->
						<h4 class="txt13 m-b-33">
							Contact Us
							<br>
						</h4>
							<ul class="m-b-70">
							<li class="txt14 m-b-14">
								
								<p>UNIVERSITY INSTITUTE OF TECHNOLOGY ...</p>
							</li>
	
							<br><li class="txt14 m-b-14">
								<br><a herf="04712539238"><i class="fa fa-phone" aria-hidden="true"></i></a>
								
								<br><li class="tran3s round-border" style="padding:9px;color:white;">0471-2539238 </li>
	<br><br>                </li>
							
						</ul>
	
						<!-- - -->
						<h4 class="txt13 m-b-32">
							Opening Times
						</h4>
	
						<ul class="tran3s round-border" style="padding:9px;color:white;">
							<li class="txt14" >
								09:30 AM – 3:30 PM
							</li><br>
	
							<li class="txt14">
							Working Days
							</li>
						</ul>
					</div>
	
					<div class="col-sm-6 col-md-4 p-t-50">
						<!-- - -->
						<h4 class="txt13 m-b-33">
							Useful Links
							<br>
							<br>
							<br>

						</h4>
	
						<div class="m-b-25" aria-hidden="true">
					<!--		<span class="fs-13 color2 m-r-5">
								<i class="fa fa-twitter" aria-hidden="true"></i>
							</span>-->
							
							<a href="#" class="txt15" aria-hidden="true" style="padding:9px;color:#ffff ;">
							Online Anti Ragging Affidavit 
							</a>
							<a href="#" class="txt15"aria-hidden="true" style="padding:9px;color:#ffff ;">
								Online Anti Ragging Complain 
							</a>
							<a href="#" class="txt15" aria-hidden="true" style="padding:9px;color:#ffff ;">
								UGC Scholarships and Fellowships 
							</a><br>
							<a href="#" class="txt15" aria-hidden="true" style="padding:9px;color:#ffff ;">
								Educational Loan 
							</a>
							
							
							
				
						</div>
					</div>
                    <div class="col-sm-6 col-md-4 p-t-50">
						<!-- - -->
						<h4 class="txt13 m-b-38">
							follow us
							<br>
							<br>
						</h4>
	
					
						<div >
							
							
							<ul>
							<div class="col-sm-6 col-md-4 p-t-50" >
								<li><a href="#" class="tran3s round-border" style="padding:9px;color:white;"><i class="fa fa-google" aria-hidden="true"></i></a></li>
						   </div> 
							<div  class="col-sm-6 col-md-4 p-t-50">
								
								<li><a href="#" class="tran3s round-border" style="padding:9px;color:blue ;"><i class="fa fa-facebook" aria-hidden="true" ></i></a></li>
							
						     </div>
							<div class="col-sm-6 col-md-4 p-t-50" >
								
								<li><a href="#" class="tran3s round-border" style="padding:9px;color:rgb(202, 43, 96);"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							</ul>
						</div>


	




					<script>
						(function(){
							"use strict";
							
							//alert('It is best to view this on desktop.');
							
							const closeViewer = function(){
								let overlay = document.getElementsByClassName('overlay')[0],
									window = document.getElementsByClassName('window')[0];
			
								overlay.classList.remove('show');
								window.classList.remove('show');
			
								setTimeout(function(){
									overlay.parentNode.removeChild(overlay);
									window.parentNode.removeChild(window);
								}, 200);
							}
			
							const imageViewer = function(){
								let overlay = document.createElement('div'),
									window = document.createElement('div'),
									img = document.createElement('img'),
									hint = document.createElement('span');
			
								overlay.classList.add('overlay');
								window.classList.add('window');
								
								img.src = this.style.backgroundImage.slice(4, -1).replace(/"/g, '');
								hint.className = 'description';
								hint.appendChild(document.createTextNode('Click / Tap outside of the image to close the preview.'));
								
								window.appendChild(img);
								window.appendChild(hint);
			
								document.getElementsByClassName('viewer')[0].appendChild(overlay);
								document.getElementsByClassName('viewer')[0].appendChild(window);
			
								overlay.addEventListener('click', closeViewer);
			
								setTimeout(function(){
									overlay.classList.add('show');
									window.classList.add('show');
								}, 10);
							}
			
							let images = document.querySelectorAll('.vishal');
							images.forEach(function(img){
								img.addEventListener('click', imageViewer); 
							});
						})();
					</script>
	
















					
					


<!--

























							<a class="item-gallery-footer wrap-pic-w" href="images/photo-gallery-04.jpg" data-lightbox="gallery-footer">
								<img src="images/photo-gallery-thumb-04.jpg" alt="GALLERY">
							</a>
	
							<a class="item-gallery-footer wrap-pic-w" href="images/photo-gallery-05.jpg" data-lightbox="gallery-footer">
								<img src="images/photo-gallery-thumb-05.jpg" alt="GALLERY">
							</a>
	
							<a class="item-gallery-footer wrap-pic-w" href="images/photo-gallery-06.jpg" data-lightbox="gallery-footer">
								<img src="images/photo-gallery-thumb-06.jpg" alt="GALLERY">
							</a>
	
							<a class="item-gallery-footer wrap-pic-w" href="images/photo-gallery-07.jpg" data-lightbox="gallery-footer">
								<img src="images/photo-gallery-thumb-07.jpg" alt="GALLERY">
							</a>
	
							<a cAs="item-gallery-footer wrap-pic-w" href="images/photo-gallery-08.jpg" data-lightbox="gallery-footer">
								<img src="images/photo-gallery-thumb-08.jpg" alt="GALLERY">
							</a>
	
							<a cAs="item-gallery-footer wrap-pic-w" href="images/photo-gallery-09.jpg" data-lightbox="gallery-footer">
							<img src="images/photo-gallery-thumb-09.jpg" alt="GALLERY">
							</a>
	
							<a class="item-gallery-footer wrap-pic-w" href="images/photo-gallery-10.jpg" data-lightbox="gallery-footer">
								<img src="images/photo-gallery-thumb-10.jpg" alt="GALLERY">
							</a>
	
							<a class="item-gallery-footer wrap-pic-w" href="images/photo-gallery-11.jpg" data-lightbox="gallery-footer">
								<img src="images/photo-gallery-thumb-11.jpg" alt="GALLERY">
							</a>
						
							<div class="item-gallery-footer wrap-pic-w" style="background-image:url(images/photo-gallery-01.jpg);" data-lightbox="gallery-footer">
								<img src="images/photo-gallery-01.jpg" alt="GaLLERY">
							</div>

							-->
						</div>
	
					</div>
				</div>
			</div>







			<style>



				.overlay {
					background: rgba(0,0,0,.85);
					bottom: 0;
					left: 0;
					opacity: 0;
					position: fixed;
					right: 0;
					transition: opacity 100ms ease-in-out;
					top: 0;
					z-index: 10000;
				}
				
				.window {
					left: 50%;
					opacity: 0;
					padding: 2rem;
					position: fixed;
					top: 50%;
					transform: translate(-50%, -50%) scale(.75);
					transition-property: opacity, transform;
					transition: 450ms cubic-bezier(.5, 0, .25, 1.5);
					z-index: 10010;
				}
				
				.window img {
					border-radius: .25rem;
					display: block;
					height: auto;
					margin-bottom: .5rem;
					max-width: 20rem;
				}
				
				.overlay.show {
					opacity: .85;
				}
				
				.window.show {
					opacity: 1;
					transform: translate(-50%, -50%) scale(1);
				}
				
				
				
				
				
				</style>
				
				
				






	
			<div class="end-footer bg2">
				<div class="container">
					<div class="flex-sb-m flex-w p-t-22 p-b-22">
					<!--	<div class="p-t-5 p-b-5">
							<a href="#" class="fs-15 c-white"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
							<a href="#" class="fs-15 c-white"><i class="fa fa-facebook m-l-18" aria-hidden="true"></i></a>
							<a href="#" class="fs-15 c-white"><i class="fa fa-twitter m-l-18" aria-hidden="true"></i></a>
						</div>
	
						<div class="txt17 p-r-20 p-t-5 p-b-5">
							Copyright &copy; 2018 All rights reserved  |  This template is made with <i class="fa fa-heart"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
						</div>-->
					</div>
				</div>
			</div>
		</footer>
	




















			<!-- =============================================
				Loading Transition
			============================================== -->
			<div id="loader-wrapper">
				<div id="preloader_1">
	                <span></span>
	                <span></span>
	                <span></span>
	                <span></span>
	                <span></span>
	            </div>
			</div>

			

	        <!-- Scroll Top Button -->
			<button class="scroll-top tran3s p-color-bg">
				<i class="fa fa-long-arrow-up" aria-hidden="true"></i>
			</button>




		<!-- Js File_________________________________ -->

		<!-- j Query -->
		<script type="text/javascript" src="vendor/jquery.2.2.3.min.js"></script>

		<!-- Bootstrap JS -->
		<script type="text/javascript" src="vendor/bootstrap/bootstrap.min.js"></script>

		<!-- Vendor js _________ -->
		
		<!-- owl.carousel -->
		<script type="text/javascript" src="vendor/owl-carousel/owl.carousel.min.js"></script>
		<!-- mixitUp -->
		<script type="text/javascript" src="vendor/jquery.mixitup.min.js"></script>
		<!-- Progress Bar js -->
		<script type="text/javascript" src="vendor/skills-master/jquery.skills.js"></script>
		<!-- Validation -->
		<script type="text/javascript" src="vendor/contact-form/validate.js"></script>
		<script type="text/javascript" src="vendor/contact-form/jquery.form.js"></script>
		<!-- Calendar js -->
		<script type="text/javascript" src="vendor/monthly-master/js/monthly.js"></script>


		<!-- Theme js -->
		<script type="text/javascript" src="js/theme.js"></script>
		<script type="text/javascript" src="js/map-script.js"></script>
		
		</div> <!-- /.main-page-wrapper -->
	</body>
</html>
